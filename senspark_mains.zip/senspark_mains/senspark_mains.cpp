#include "senspark_mains.h"
#include <Arduino.h>
#include <EEPROM.h>
#include <ESP8266WiFi.h>
#include <ESP8266WiFiMulti.h>

#include <ESP8266HTTPClient.h>
#include <ESP8266httpUpdate.h>

String _ssid;
String _pass;
senspark_mains::senspark_mains()
{
}
void update_started()
{
    Serial.println("Activation started");
    Serial.println("Downloading firmware");
}

void update_finished()
{
    Serial.println("Spark activated successfully");
    Serial.println("Congratulations and welcome to Senspark");
}

void update_progress(int cur, int total)
{
    int progress = (float(cur) / float(total)) * 100;

    if (progress <= 50)
    {
        Serial.printf("Downlaoding firmware %d%% completed ...\n", progress);
    }
    if (progress > 50 && progress <= 70)
    {
        Serial.printf("Verifying firmware %d%% completed ...\n", progress);
    }
    if (progress > 70)
    {
        Serial.printf("Installing firmware %d%% completed ...\n", progress);
    }
}

void update_error(int err)
{
    Serial.printf("Activation failed");
}

boolean senspark_mains::initialize(String ssid, String pass)
{
    _ssid = ssid;
    _pass = pass;
    delay(5000);
    int i = 0;
    Serial.println("Initializing your Spark device");
    WiFi.begin(ssid, pass);
    Serial.println("Connecting");
    while (WiFi.status() != WL_CONNECTED && i < 45)
    {

        Serial.print(".");
        delay(1000);
        i++;
    }
    if (WiFi.status() == WL_CONNECTED)
    {
        Serial.println("Connected");
        Serial.println("Connecting to Spark servers");
        return true;
    }
    else
    {
        Serial.println("Unable to connect with the given credentials");
        return false;
    }
}

void senspark_mains::activate(String projectid, String deviceid)
{
    if (_ssid.length() > 0 && _pass.length() > 0)
    {
        //Serial.println("clearing eeprom");
        for (int i = 0; i < 150; ++i)
        {
            EEPROM.write(i, 0);
        }
        // Serial.println(qsid);
        // Serial.println("");
        // Serial.println(qpass);
        // Serial.println("");

        // Serial.println("writing eeprom ssid:");
        for (unsigned i = 0; i < _ssid.length(); i++)
        {
            EEPROM.write(i, _ssid[i]);
            // Serial.print("Wrote: ");
            // Serial.println(qsid[i]);
        }
        // Serial.println("writing eeprom pass:");
        for (unsigned i = 0; i < _pass.length(); ++i)
        {
            EEPROM.write(32 + i, _pass[i]);
            // Serial.print("Wrote: ");
            // Serial.println(qpass[i]);
        }
        // Serial.println("writing eeprom projectid:");
        for (unsigned i = 0; i < projectid.length(); ++i)
        {
            EEPROM.write(96 + i, projectid[i]);
            // Serial.print("Wrote: ");
            // Serial.println(projectid[i]);
        }
        for (unsigned i = 0; i < deviceid.length(); ++i)
        {
            EEPROM.write(120 + i, deviceid[i]);
            // Serial.print("Wrote: ");
            // Serial.println(deviceid[i]);
        }
        for (unsigned i = 0; i < 6; ++i)
        {
            EEPROM.write(134 + i, '#');
            // Serial.print("Wrote: ");
            // Serial.println('#');
        }
        EEPROM.commit();
    }
    WiFiClient client;

    ESPhttpUpdate.setLedPin(LED_BUILTIN, LOW);

    // Add optional callback notifiers
    ESPhttpUpdate.onStart(update_started);
    ESPhttpUpdate.onEnd(update_finished);
    ESPhttpUpdate.onProgress(update_progress);
    ESPhttpUpdate.onError(update_error);

    //    t_httpUpdate_return ret = ESPhttpUpdate.update(client, "http://server/file.bin");
    //     Or:
    t_httpUpdate_return ret = ESPhttpUpdate.update(client, "api.senspark.io", 3000, "/download/firmware/base.bin");

    switch (ret)
    {
    case HTTP_UPDATE_FAILED:
        Serial.printf("HTTP_UPDATE_FAILD Error (%d): %s\n", ESPhttpUpdate.getLastError(), ESPhttpUpdate.getLastErrorString().c_str());
        break;

    case HTTP_UPDATE_NO_UPDATES:
        Serial.println("HTTP_UPDATE_NO_UPDATES");
        break;

    case HTTP_UPDATE_OK:
        Serial.println("HTTP_UPDATE_OK");
        break;
    }
}