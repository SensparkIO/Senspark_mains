#ifndef senspark_mains_H
#define senspark_mains_H

#include <Arduino.h>

#include <ESP8266WiFi.h>
#include <ESP8266WiFiMulti.h>

#include <ESP8266HTTPClient.h>
#include <ESP8266httpUpdate.h>

class senspark_mains
{
public:
    senspark_mains();
    boolean initialize(String ssid, String pass);
    void activate(String projectid, String deviceid);
};
#endif